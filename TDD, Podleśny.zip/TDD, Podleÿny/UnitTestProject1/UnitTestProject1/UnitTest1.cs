﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void MetodaToStringZwracaImieOrazNazwisko()
        { 
            var osoba = new Osoba() //Tworzona jest zmienna osoba, która przyjmuje wartość Imie i Nazwisko
            {
                        Imie = "Jacek",
                        Nazwisko = "Kaczmarczyk"
            };
            Assert.AreEqual("Jacek Kaczmarczyk", osoba.ToString()); 
            //Sprawdzenie w nawiasach wartości, czy string i czy należy do zmiennej osoba
        }

        [TestMethod] //2 test jednostkowy
        public void MetodaWiekZwracaIloscLatOsoby()
            {
                var osoba = new Osoba
                {
                    Imie = "Jacek",
                    Nazwisko = "Kaczmarczyk",
                    DataUrodzenia = new DateTime(1993, 09, 24)
                };
                Assert.AreEqual(23, osoba.Wiek); //Najpierw sprawdza z oryginalnym wiekiem
                                                 //Porównanie z wiekiem wyliczony, gdy jest prawidłowy to test się kończy pozytywnie.
            }
    }
}
