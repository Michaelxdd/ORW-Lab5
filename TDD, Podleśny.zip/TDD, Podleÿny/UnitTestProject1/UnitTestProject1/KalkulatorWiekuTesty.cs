﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class KalkulatorWiekuTesty
    {
        private static int RokTestowy = 1989;
        private static int MiesiacTestowy = 03;
        private static int DzienTestowy = 19;

        private int OczekiwanaIloscLat = DateTime.Now.Year - RokTestowy;
        private IWiek _osoba;


        [TestInitialize]
        public void Setup()
        {
            _osoba = new Osoba()
            {
                Imie = "Jacek",
                Nazwisko = "Kaczmarczyk",
                DataUrodzenia = new DateTime(RokTestowy, MiesiacTestowy, DzienTestowy)
            };
        }

        [TestMethod]
        public void MetodaObliczZwracaIloscLat()
        {
            var kalkulatorWieku = new KalkulatorWieku(_osoba);
            Assert.AreEqual(OczekiwanaIloscLat, kalkulatorWieku.Oblicz());
        }
    }
}
